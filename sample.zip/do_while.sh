#!/bin/bash
echo "Enter a limit"
read n
echo " Printing first $n natural numbers"
a="y"
while 
	echo $a
	a=$a"y"
	echo $a
	[ "$a" == "y" ]
do :;
done
